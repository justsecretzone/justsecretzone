# GitHub-Profil Setup: justsecretzone

## 1. Profil-Einstellungen (github.com/settings/profile)

| Feld | Eintrag |
|---|---|
| **Name** | Justus Langowsky |
| **Bio** (max. 160 Zeichen) | Founder & full-stack engineer. Building Algosail - no-code algo trading. AI agents, MCP, trading infrastructure. |
| **Pronomen** | he/him (optional) |
| **Company** | Algosail |
| **Location** | Dresden, Germany |
| **Website** | https://langowsky.com |
| **Social accounts** | LinkedIn, X/Twitter (falls vorhanden) |
| **Profilbild** | Echtes, professionelles Foto, neutraler Hintergrund |

Alternative Bios:
- `Building AI-native products end to end. Founder of Algosail. TypeScript · Python · MCP · Trading systems.`
- `Solo founder shipping fast. Algo trading, AI agents, defense tech. Dresden → Norway.`

**Tipp:** Benutzername überlegen. `justsecretzone` wirkt eher wie ein Gamer-Tag. Für Investoren und Kunden ist `justuslangowsky` oder `jlangowsky` stärker. Umbenennen geht unter Settings > Account; GitHub leitet alte Repo-URLs weiter. Falls du umbenennst, im README alle `justsecretzone` ersetzen.

## 2. Profil-README aktivieren

1. Neues **öffentliches** Repo mit exakt deinem Benutzernamen anlegen: `justsecretzone`
2. Häkchen "Add a README file" setzen
3. Inhalt von `README.md` aus diesem Ordner einfügen
4. Platzhalter ersetzen: `DEIN-LINKEDIN`, `DEINE-MAIL`, Zertifikate

## 3. Zertifikate

Im README ist ein Block mit zwei Platzhalter-Badges. Für jedes Zertifikat ein Badge:

```html
<a href="LINK-ZUM-NACHWEIS"><img src="https://img.shields.io/badge/NAME-ANBIETER-FARBE?style=for-the-badge&logo=LOGO&logoColor=white" /></a>
```

- Leerzeichen im Namen als `_` schreiben, Bindestriche als `--`
- Logos: Namen von https://simpleicons.org (z.B. `amazonaws`, `googlecloud`, `anthropic`, `microsoft`)
- Wenn Credly-Badges vorhanden: das offizielle Badge-Bild von Credly direkt einbinden, wirkt noch seriöser

Claude 101 (Anthropic) ist eingebaut. Das Badge verlinkt auf `assets/claude-101-certificate.jpg` im Profil-Repo. Falls du einen offiziellen Verifizierungslink hast, ersetze den Link damit.

## 4. Repos aufräumen

1. **Pinnen** (Profil > Customize your pins): max. 6. Empfehlung: Algosail, Mission Control, MCP Toolkit, Pine Indicators, Dailysites CRM
2. Jedes Repo bekommt: **Description**, **Website-Link**, **Topics** (z.B. `nextjs`, `trading`, `mcp`, `ai-agents`, `pine-script`)
3. READMEs aus `Projekt-READMEs/` als `README.md` ins jeweilige Repo
4. Screenshots oder GIFs unter `docs/preview.png` ablegen - das ist der größte Qualitätssprung
5. Alte, halbfertige oder Test-Repos archivieren oder auf privat stellen
6. Social Preview Image setzen (Repo > Settings > Social preview, 1280×640)

**Private Code bleibt privat:** Für Algosail reicht ein öffentliches "Showcase"-Repo mit README, Screenshots und Architektur, ohne den eigentlichen Code. Telron bewusst nicht öffentlich nennen (NDA, Patent noch nicht eingereicht) - im README steht nur "defense-tech startup (stealth)".

## 5. Aktivität sichtbar machen

- Settings > Public profile: **"Include private contributions on my profile"** aktivieren, damit private Commits im Contribution-Graph zählen
- **Achievements** anzeigen lassen (gleiche Seite)
- Commit-E-Mail prüfen: deine Git-Mail muss in GitHub hinterlegt sein, sonst zählen Commits nicht

## 6. Widgets

| Widget | Quelle |
|---|---|
| Header / Footer Welle | capsule-render.vercel.app |
| Tech-Icons | skillicons.dev |
| Stats + Top-Sprachen | github-readme-stats |
| Streak | streak-stats.demolab.com |
| Aktivitätsgraph | github-readme-activity-graph |
| Profile Views | komarev.com |

**Wichtig:** Die öffentliche `github-readme-stats.vercel.app` ist oft überlastet und zeigt dann Fehler. Stabil wird es nur mit eigener Instanz: Repo `anuraghazra/github-readme-stats` forken, auf Vercel deployen, `PAT_1` (GitHub Token) als Env-Variable setzen und die URL im README auf deine Vercel-Domain umstellen.

## 7. Optional, für den Extra-Effekt

- **Snake-Animation** (Contribution-Graph wird gefressen): GitHub Action `Platane/snk`
- **GitHub Sponsors** oder **Hireable**-Status aktivieren
- Eigene **Organisation** `algosail` anlegen und das Projekt dort hosten - wirkt wie ein echtes Unternehmen
