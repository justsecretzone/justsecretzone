<div align="center">

# ⛵ Algosail

**Build, backtest and deploy algorithmic trading strategies without writing code.**

[![Next.js](https://img.shields.io/badge/Next.js-000?style=flat-square&logo=nextdotjs)](https://nextjs.org)
[![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=flat-square&logo=typescript&logoColor=white)](https://www.typescriptlang.org)
[![Python](https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white)](https://python.org)
[![MetaTrader 5](https://img.shields.io/badge/MetaTrader_5-0B5394?style=flat-square)](https://www.metatrader5.com)
![Status](https://img.shields.io/badge/status-in_development-1f6feb?style=flat-square)

<!-- Screenshot oder GIF hier einfügen: ![Algosail](./docs/preview.png) -->

</div>

---

## Overview

Algosail lets retail traders turn their trading ideas into automated strategies. Instead of wiring nodes or writing MQL5, users draw their setups directly on the chart, explain them in plain language, and Algosail's AI generates production-ready code for **MQL5, Pine Script and Python**.

## Features

- **Chart-based strategy builder** - draw long/short setups with SL, TP1-3, break-even and trailing rules directly on the chart
- **AI strategy memory** - the AI learns from annotated examples (including negative examples) and improves the generated logic
- **Built-in IDE** - edit, compile and version strategies in MQL5, Pine Script and Python
- **Tick-level backtesting** - backtests run on Algosail's own market data including intra-candle price action
- **Broker connectivity** - live prices from connected brokers, MetaTrader 5 support at launch
- **Liquid Glass UI** - custom design system, optimized for desktop and mobile

## Architecture

```
┌──────────────┐     ┌──────────────────┐     ┌────────────────┐
│  Web / App   │────▶│  Algosail API    │────▶│  Backtest      │
│  (Next.js)   │     │  (Node / Python) │     │  Engine (Py)   │
└──────────────┘     └────────┬─────────┘     └────────────────┘
                              │
                     ┌────────▼─────────┐     ┌────────────────┐
                     │  AI Code Gen     │     │  MT5 Executor  │
                     │  (LLM + Memory)  │────▶│  (Connector)   │
                     └──────────────────┘     └────────────────┘
```

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js, React, Tailwind CSS, Lightweight Charts |
| Backend | Node.js, Python, Prisma, PostgreSQL |
| AI | Anthropic API, AWS Bedrock |
| Trading | MetaTrader 5, MQL5, Pine Script v5 |
| Data | Dukascopy tick data |
| Payments | Stripe |

## Roadmap

- [x] Built-in IDE for MQL5, Pine and Python
- [x] Backtest engine with trade visualization
- [ ] Chart-based strategy builder (replacing the node builder)
- [ ] Multi-broker symbol search
- [ ] Strategy marketplace

## License

Proprietary. All rights reserved. © 2026 Justus Langowsky
