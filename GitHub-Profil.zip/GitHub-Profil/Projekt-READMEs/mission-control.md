<div align="center">

# 🛰️ Mission Control

**A personal AI orchestration platform that runs 24/7 on a Mac Mini M4.**

![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=flat-square&logo=typescript&logoColor=white)
![MCP](https://img.shields.io/badge/MCP-Model_Context_Protocol-D97757?style=flat-square)
![Ollama](https://img.shields.io/badge/Ollama-local_LLM-000?style=flat-square)
![Three.js](https://img.shields.io/badge/Three.js-000?style=flat-square&logo=threedotjs)

<!-- ![Mission Control](./docs/preview.gif) -->

</div>

---

## Overview

Mission Control (codename *Jarvis*) is an always-on hub that coordinates multiple AI agents, local and cloud models, voice and messaging. It uses an Obsidian vault as its long-term "brain" and exposes everything through MCP.

## Features

- **Multi-brain architecture** - routes tasks between local (Ollama, qwen3:8b) and cloud models
- **Voice copilot** - natural voice interaction powered by ElevenLabs
- **Agent policy system** - fine-grained rules for what each agent may read, write and execute
- **Obsidian as memory** - structured, human-readable knowledge base
- **Messaging gateway** - MCP gateway for chat and notifications
- **Live visualization** - Three.js particle sphere reacting to agent activity

## Tech Stack

TypeScript · Node.js · MCP · Ollama · ElevenLabs · Obsidian · Three.js · macOS

## License

MIT
