<div align="center">

# 📇 Dailysites CRM

**Lead generation and sales CRM for local web agency sales.**

![Next.js](https://img.shields.io/badge/Next.js-000?style=flat-square&logo=nextdotjs)
![Prisma](https://img.shields.io/badge/Prisma-2D3748?style=flat-square&logo=prisma)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-4169E1?style=flat-square&logo=postgresql&logoColor=white)

<!-- ![Dailysites CRM](./docs/preview.png) -->

</div>

---

## Overview

An internal sales tool built for selling websites to small local businesses. It finds businesses without a modern web presence, enriches the leads and manages the full outreach pipeline.

## Features

- **Google Maps scraper** - discovers local businesses by region and category
- **Lead enrichment** - website check, contact data, scoring
- **Pipeline board** - track leads from first contact to signed deal
- **Email outreach** - templated mails with tracking
- **Region focus** - built for eastern Saxony, easily configurable for other markets

## Tech Stack

Next.js · TypeScript · Prisma · PostgreSQL · Tailwind CSS · Vercel

## Getting Started

```bash
git clone https://github.com/justsecretzone/dailysites-crm.git
cd dailysites-crm
npm install
cp .env.example .env   # add DATABASE_URL and API keys
npx prisma migrate dev
npm run dev
```

## License

MIT
