<div align="center">

# 📈 Pine Indicators

**Open-source TradingView indicators with built-in backtest tables.**

![Pine Script](https://img.shields.io/badge/Pine_Script-v5-1f6feb?style=flat-square)
![TradingView](https://img.shields.io/badge/TradingView-131722?style=flat-square&logo=tradingview)
![License](https://img.shields.io/badge/license-MIT-30363d?style=flat-square)

</div>

---

## Indicators

| Indicator | Description |
|---|---|
| **iFVG + MA Channel** | Inverse fair value gaps combined with a moving average channel, 20-row backtest table |
| **EMA Crossover Retest** | Entries on the retest after an EMA cross |
| **MA Body Cross** | Signals when a candle body fully crosses a moving average |
| **Noise Zone Detector** | Highlights choppy zones where trend strategies underperform |
| **Engulfing / Topping Candles** | Reversal pattern detection with trade visualization |

## Usage

1. Open TradingView and the Pine Editor
2. Copy the `.pine` file from this repo
3. Click **Add to chart**

## Disclaimer

For educational purposes only. Not financial advice. Past performance does not guarantee future results.

## License

MIT
