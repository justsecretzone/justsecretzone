<div align="center">

# 🧰 MCP Toolkit

**A collection of Model Context Protocol servers for Claude and other AI clients.**

![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=flat-square&logo=typescript&logoColor=white)
![MCP](https://img.shields.io/badge/MCP-compatible-D97757?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-1f6feb?style=flat-square)

</div>

---

## Servers

| Server | What it does |
|---|---|
| **PromptMeter** | Scores prompt quality and suggests improvements before you send them |
| **Local FLUX** | Generates images locally with FLUX.2 via ComfyUI, no cloud needed |
| **VibeGym** | Suggests short workouts while you wait for your AI agent to finish |
| **Patchbook** | Patch management for Claude Code workflows on macOS |

## Installation

Add a server to your MCP client config:

```json
{
  "mcpServers": {
    "promptmeter": {
      "command": "npx",
      "args": ["-y", "@justsecretzone/promptmeter"]
    }
  }
}
```

## Contributing

Issues and pull requests are welcome.

## License

MIT
